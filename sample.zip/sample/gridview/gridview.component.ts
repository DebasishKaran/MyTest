import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

import { GridViewService } from '../services/gridview.service';
import { ToastComponent } from '../shared/toast/toast.component';
import { GridView } from '../shared/models/gridview.model';

@Component({
  selector: 'app-gridview',
  templateUrl: './gridview.component.html',
  styleUrls: ['./gridview.component.scss']
})
export class StudiesComponent implements OnInit {

  Study = new GridView();
  gridview: GridView[] = [];
  isLoading = true;
  isEditing = false;

  addGridViewForm: FormGroup;
  studyname = new FormControl('', Validators.required);
  conceptcd = new FormControl('', Validators.required);
  conceptpath = new FormControl('', Validators.required);
  namechar = new FormControl('', Validators.required);

  constructor(private gridviewService: GridViewService,
              private formBuilder: FormBuilder,
              public toast: ToastComponent) { }

  ngOnInit() {
    this.getgetGridView();
    this.addGridViewForm = this.formBuilder.group({
      studyname: this.studyname,
      conceptcd: this.conceptcd,
      conceptpath: this.conceptpath,
	  namechar: this.namechar
    });
  }

  getGridView() {
    this.gridviewService.getGridView().subscribe(
      data => this.gridview = data,
      error => console.log(error),
      () => this.isLoading = false
    );
  }

 

  
}

import * as mongoose from 'mongoose';

const studySchema = new mongoose.Schema({
  studyname: String,
  projectname: String,
  puid: String
});

const Study = mongoose.model('Study', studySchema);

export default Study;

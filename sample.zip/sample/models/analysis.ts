import * as mongoose from 'mongoose';

const gridviewSchema = new mongoose.Schema({
  studyname: String,
  conceptcd: String,
  conceptpath: String,
  namechar: String  
});

const GridView = mongoose.model('GridView', gridviewSchema);

export default GridView;

import * as mongoose from 'mongoose';

const reportdesignSchema = new mongoose.Schema({
  studyname: String,
  sitename: String,
  subjectid: String,
  visitname: String,
  datalabel: String,
  datavalue: String,
  categorycd: String  
});

const ReportDesign = mongoose.model('ReportDesign', reportdesignSchema);

export default ReportDesign;

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';

import { GridView } from '../shared/models/gridview.model';

@Injectable()
export class GridViewService {

  constructor(private http: HttpClient) { }

  getGridView(): Observable<GridView[]> {
    return this.http.get<gridview[]>('/api/gridview');
  }

  getGridView(gridview: GridView): Observable<GridView> {
    return this.http.get<gridview>(`/api/gridview/${gridview._id}`);
  }
  
  }

}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';

import { ReportDesign } from '../shared/models/reportdesign.model';

@Injectable()
export class ReportDesignService {

  constructor(private http: HttpClient) { }

  getReportDesign(): Observable<reportdesign[]> {
    return this.http.get<reportdesign[]>('/api/reportdesign');
  }

  getreportdesign(reportdesign: ReportDesign): Observable<reportdesign> {
    return this.http.get<reportdesign>(`/api/reportdesign/${reportdesign._id}`);
  }

  editreportdesign(reportdesign: ReportDesign): Observable<string> {
    return this.http.put(`/api/reportdesign/${reportdesign._id}`, reportdesign, { responseType: 'text' });
  }

  deletereportdesign(reportdesign: ReportDesign): Observable<string> {
    return this.http.delete(`/api/reportdesign/${reportdesign._id}`, { responseType: 'text' });
  }

}

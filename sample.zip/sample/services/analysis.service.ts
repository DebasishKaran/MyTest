import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';

import { Analysis } from '../shared/models/gridview.model';

@Injectable()
export class AnalysisService {

  constructor(private http: HttpClient) { }

  getAnalysis(): Observable<Analysis[]> {
    return this.http.get<analysis[]>('/api/analysis');
  }

  getAnalysis(analysis: Analysis): Observable<Analysis> {
    return this.http.get<analysis>(`/api/analysis/${analysis._id}`);
  }
  
  }

}

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

import { ReportDesignService } from '../services/ReportDesign.service';
import { ToastComponent } from '../shared/toast/toast.component';
import { ReportDesign } from '../shared/models/ReportDesign.model';

@Component({
  selector: 'app-reportdesign',
  templateUrl: './reportdesign.component.html',
  styleUrls: ['./reportdesign.component.scss']
})
export class ReportDesignComponent implements OnInit {

  ReportDesign = new ReportDesign();
  ReportDesign: ReportDesign[] = [];
  isLoading = true;
  isEditing = false;

  addReportDesignForm: FormGroup;
  ReportDesignname = new FormControl('', Validators.required);
  projectname = new FormControl('', Validators.required);
  puid = new FormControl('', Validators.required);

  constructor(private ReportDesignService: ReportDesignService,
              private formBuilder: FormBuilder,
              public toast: ToastComponent) { }

  ngOnInit() {
    this.getReportDesigns();
    this.addReportDesignForm = this.formBuilder.group({
      ReportDesignname: this.ReportDesignname,
      projectname: this.projectname,
      puid: this.puid
    });
  }

  getReportDesigns() {
    this.ReportDesignService.getStudies().subscribe(
      data => this.ReportDesign = data,
      error => console.log(error),
      () => this.isLoading = false
    );
  }

  
  enableEditing(ReportDesign: ReportDesign) {
    this.isEditing = true;
    this.ReportDesign = ReportDesign;
  }

  cancelEditing() {
    this.isEditing = false;
    this.ReportDesign = new ReportDesign();
    this.toast.setMessage('item editing cancelled.', 'warning');
    // reload the ReportDesign to reset the editing
    this.getStudies();
  }

  editReportDesign(ReportDesign: ReportDesign) {
    this.ReportDesignService.editReportDesign(ReportDesign).subscribe(
      () => {
        this.isEditing = false;
        this.ReportDesign = ReportDesign;
        this.toast.setMessage('item edited successfully.', 'success');
      },
      error => console.log(error)
    );
  }

  deleteReportDesign(ReportDesign: ReportDesign) {
    if (window.confirm('Are you sure you want to permanently delete this item?')) {
      this.ReportDesignService.deleteReportDesign(ReportDesign).subscribe(
        () => {
          const pos = this.ReportDesign.map(elem => elem._id).indexOf(ReportDesign._id);
          this.ReportDesign.splice(pos, 1);
          this.toast.setMessage('item deleted successfully.', 'success');
        },
        error => console.log(error)
      );
    }
  }

}

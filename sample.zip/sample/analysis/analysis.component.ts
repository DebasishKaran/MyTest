import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

import { AnalysisService } from '../services/analysis.service';
import { ToastComponent } from '../shared/toast/toast.component';
import { Analysis } from '../shared/models/analysis.model';

@Component({
  selector: 'app-analysis',
  templateUrl: './analysis.component.html',
  styleUrls: ['./analysis.component.scss']
})
export class StudiesComponent implements OnInit {

  analysis = new Analysis();
  analysis: Analysis[] = [];
  isLoading = true;
  isEditing = false;

  addAnalysisForm: FormGroup;
  studyname = new FormControl('', Validators.required);
  conceptcd = new FormControl('', Validators.required);
  conceptpath = new FormControl('', Validators.required);
  namechar = new FormControl('', Validators.required);

  constructor(private analysisService: AnalysisService,
              private formBuilder: FormBuilder,
              public toast: ToastComponent) { }

  ngOnInit() {
    this.getAnalysis();
    this.addAnalysisForm = this.formBuilder.group({
      studyname: this.studyname,
      conceptcd: this.conceptcd,
      conceptpath: this.conceptpath,
	  namechar: this.namechar
    });
  }

  getAnalysis() {
    this.analysisService.getAnalysis().subscribe(
      data => this.analysis = data,
      error => console.log(error),
      () => this.isLoading = false
    );
  }

 

  
}

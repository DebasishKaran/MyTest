import * as bcrypt from 'bcryptjs';
import * as mongoose from 'mongoose';

const changepasswordSchema new mongoose.Schema({
  username: String,
  password: String  
});

changepasswordSchema.pre('save', function(next) {
  const user = this;
  if (!user.isModified('password')) { return next(); }
  bcrypt.genSalt(10, function(err, salt) {
    if (err) { return next(err); }
    bcrypt.hash(user.password, salt, function(error, hash) {
      if (error) { return next(error); }
      user.password = hash;
      next();
    });
  });
});

const UserChangePassword = mongoose.model('User', changepasswordSchema);

export default UserChangePassword;

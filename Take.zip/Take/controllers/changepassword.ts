import * as dotenv from 'dotenv';
import * as jwt from 'jsonwebtoken';

import UserChangePassword from '../models/changepassword';
import BaseCtrl from './base';

export default class ChangePasswordCtrl extends BaseCtrl {
  model = UserChangePassword;
}

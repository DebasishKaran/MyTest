import { Component, OnInit } from '@angular/core';

import { ToastComponent } from '../shared/toast/toast.component';
import { AuthService } from '../services/auth.service';
import { UserService } from '../services/user.service';
import { User } from '../shared/models/user.model';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html'
})
export class ChangePasswordComponent implements OnInit {

  users: User[] = [];
  isLoading = true;

  constructor(public auth: AuthService,
              public toast: ToastComponent,
              private userService: UserService) { }

  ngOnInit() {
    this.getUsers();
  }

  getUsers() {
    this.userService.getUsers().subscribe(
      data => this.users = data,
      error => console.log(error),
      () => this.isLoading = false
    );
  }

  changePasswordUser(user: User) {
    if (window.confirm('Are you sure you want to change password for ' + user.username + '?')) {
      this.userService.changePasswordUser(user).subscribe(
        data => this.toast.setMessage('Password is changed successfully.', 'success'),
        error => console.log(error),
        () => this.getUsers()
      );
    }
  }

}
